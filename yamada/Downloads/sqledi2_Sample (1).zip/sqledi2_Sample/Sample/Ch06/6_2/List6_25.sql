SELECT *
  FROM SampleLike
 WHERE strcol LIKE 'abc__';