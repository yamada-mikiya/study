SELECT *
  FROM SampleLike
 WHERE strcol LIKE '%ddd';