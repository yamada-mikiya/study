--List6-4
SELECT m, n,
       ROUND(m, n) AS round_col
  FROM SampleMath;