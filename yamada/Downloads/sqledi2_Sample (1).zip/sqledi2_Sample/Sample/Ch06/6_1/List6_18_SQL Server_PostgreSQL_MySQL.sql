-- SQL Server、PostgreSQL、MySQL
SELECT CAST('2009-12-14' AS DATE) AS date_col;