SELECT COALESCE(str2, 'NULLです')
  FROM SampleStr;