--Oracle
--ダミーテーブル（DUAL）を指定
SELECT CURRENT_TIMESTAMP
  FROM dual;