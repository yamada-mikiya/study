--Oracle
--ダミーテーブル（DUAL）を指定
SELECT CURRENT_DATE
  FROM dual;