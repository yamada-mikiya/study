--Oracle、DB2、PostgreSQL、MySQL
SELECT n, p,
       MOD(n, p) AS mod_col
  FROM SampleMath;