--SQL Server
SELECT str1,
       LEN(str1) AS len_str
  FROM SampleStr;