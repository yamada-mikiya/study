--SQL Server、PostgreSQL
SELECT CAST('0001' AS INTEGER) AS int_col;