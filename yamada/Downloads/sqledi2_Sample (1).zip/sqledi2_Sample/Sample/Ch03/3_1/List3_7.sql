SELECT AVG(hanbai_tanka), AVG(shiire_tanka)
  FROM Shohin;