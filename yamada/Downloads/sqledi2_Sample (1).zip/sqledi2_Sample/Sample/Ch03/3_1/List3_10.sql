SELECT COUNT(DISTINCT shohin_bunrui)
  FROM Shohin;