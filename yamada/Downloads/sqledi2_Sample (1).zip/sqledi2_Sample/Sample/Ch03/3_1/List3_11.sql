SELECT DISTINCT COUNT(shohin_bunrui)
  FROM Shohin;