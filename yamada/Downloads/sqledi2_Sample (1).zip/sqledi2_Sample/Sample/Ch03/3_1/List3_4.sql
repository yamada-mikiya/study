SELECT SUM(hanbai_tanka)
  FROM Shohin;