SELECT shohin_mei, shiire_tanka
  FROM Shohin
 WHERE shiire_tanka = 2800;