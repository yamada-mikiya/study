--Oracle
SELECT (100 + 200) * 3 AS keisan FROM DUAL;