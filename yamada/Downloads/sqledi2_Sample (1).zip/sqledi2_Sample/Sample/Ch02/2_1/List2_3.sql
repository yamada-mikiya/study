SELECT shohin_id, shohin_mei, shohin_bunrui, hanbai_tanka,
       shiire_tanka, torokubi
  FROM Shohin;