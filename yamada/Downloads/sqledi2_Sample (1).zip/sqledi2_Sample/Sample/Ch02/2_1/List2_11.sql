SELECT shohin_mei
  FROM Shohin
 WHERE shohin_bunrui = '衣服';