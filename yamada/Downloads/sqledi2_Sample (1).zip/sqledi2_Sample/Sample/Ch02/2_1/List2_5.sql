SELECT shohin_id AS "商品ID",
       shohin_mei AS "商品名",
       shiire_tanka AS "仕入単価"
  FROM Shohin;