SELECT DISTINCT shohin_id, shiire_tanka
-- このSELECT文は、結果から重複をなくします。
  FROM Shohin;