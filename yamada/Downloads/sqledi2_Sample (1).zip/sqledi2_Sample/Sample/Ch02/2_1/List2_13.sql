-- このSELECT文は、結果から重複をなくします。
SELECT DISTINCT shohin_id, shiire_tanka
  FROM Shohin;