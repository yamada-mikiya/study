SELECT shohin_mei, shohin_bunrui
 WHERE shohin_bunrui = '衣服'
  FROM Shohin;