SELECT DISTINCT shohin_bunrui
  FROM Shohin;