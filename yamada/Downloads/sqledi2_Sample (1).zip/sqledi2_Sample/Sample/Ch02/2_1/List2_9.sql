SELECT DISTINCT shohin_bunrui, torokubi
  FROM Shohin;