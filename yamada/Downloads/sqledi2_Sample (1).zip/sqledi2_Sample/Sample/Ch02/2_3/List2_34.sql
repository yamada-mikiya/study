SELECT shohin_mei, shiire_tanka
  FROM Shohin
 WHERE shohin_bunrui = 'キッチン用品'
    OR hanbai_tanka >= 3000;