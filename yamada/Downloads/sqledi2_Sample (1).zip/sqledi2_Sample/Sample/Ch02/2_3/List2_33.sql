SELECT shohin_mei, shiire_tanka
  FROM Shohin
 WHERE shohin_bunrui = 'キッチン用品'
   AND hanbai_tanka >= 3000;