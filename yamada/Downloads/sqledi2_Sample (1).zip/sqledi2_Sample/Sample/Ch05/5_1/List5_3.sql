SELECT shohin_bunrui, cnt_shohin
  FROM ShohinSum;