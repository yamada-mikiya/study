DROP VIEW ShohinSum;

/* PostgreSQLで多段ビューの作成元となっているビューを削除する場合 */
DROP VIEW ShohinSum CASCADE;