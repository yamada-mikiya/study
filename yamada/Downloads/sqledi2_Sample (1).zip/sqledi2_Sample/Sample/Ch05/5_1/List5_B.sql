--商品ID：0009の印鑑を削除する
DELETE FROM Shohin WHERE shohin_id = '0009';