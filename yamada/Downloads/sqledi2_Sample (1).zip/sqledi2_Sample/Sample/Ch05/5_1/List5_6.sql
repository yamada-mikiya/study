INSERT INTO ShohinJim VALUES ('0009', '印鑑', '事務用品', 95, 10, '2009-11-30');

--ビューに追加されていることの確認
SELECT * FROM ShohinJim;

--元のテーブルに追加されていることの確認
SELECT * FROM Shohin;