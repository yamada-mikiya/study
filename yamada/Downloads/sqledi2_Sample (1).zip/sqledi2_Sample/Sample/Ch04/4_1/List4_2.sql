INSERT INTO ShohinIns (shohin_id, shohin_mei, shohin_bunrui, hanbai_tanka, shiire_tanka, torokubi) 
       VALUES ('0001', 'Tシャツ', '衣服', 1000, 500, '2009-09-20');


/*
-- VALUES句の値リストが1列足りない！
INSERT INTO ShohinIns (shohin_id, shohin_mei, shohin_bunrui, hanbai_tanka, shiire_tanka, torokubi) VALUES ('0001', 'Tシャツ' ,'衣服', 1000, 500);
*/