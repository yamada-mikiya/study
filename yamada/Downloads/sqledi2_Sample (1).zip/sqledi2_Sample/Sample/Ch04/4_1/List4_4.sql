INSERT INTO ShohinIns (shohin_id, shohin_mei, shohin_bunrui, hanbai_tanka, shiire_tanka, torokubi) 
       VALUES ('0006', 'フォーク', 'キッチン用品', 500, NULL, '2009-09-20');