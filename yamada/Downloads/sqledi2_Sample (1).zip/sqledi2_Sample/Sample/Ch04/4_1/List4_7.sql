INSERT INTO ShohinIns (shohin_id, shohin_mei, shohin_bunrui, shiire_tanka, torokubi) 
       VALUES ('0007', 'おろしがね', 'キッチン用品', 790, '2009-04-28');