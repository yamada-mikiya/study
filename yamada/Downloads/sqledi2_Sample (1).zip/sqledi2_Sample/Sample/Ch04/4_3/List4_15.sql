UPDATE Shohin
   SET torokubi = '2009-10-10';

--変更内容の確認
SELECT * FROM Shohin ORDER BY shohin_id;