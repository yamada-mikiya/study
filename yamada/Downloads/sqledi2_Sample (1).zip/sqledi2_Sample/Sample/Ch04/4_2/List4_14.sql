DELETE FROM Shohin
 WHERE hanbai_tanka >= 4000;

--削除結果の確認
SELECT * FROM Shohin;