--Oracle
ALTER TABLE Shohin ADD (shohin_mei_kana VARCHAR2(100));