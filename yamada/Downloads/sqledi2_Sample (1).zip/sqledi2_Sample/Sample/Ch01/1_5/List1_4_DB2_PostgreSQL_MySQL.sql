--DB2 PostgreSQL MySQL
ALTER TABLE Shohin ADD COLUMN shohin_mei_kana VARCHAR(100);