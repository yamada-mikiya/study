--MySQL
RENAME TABLE Sohin to Shohin;