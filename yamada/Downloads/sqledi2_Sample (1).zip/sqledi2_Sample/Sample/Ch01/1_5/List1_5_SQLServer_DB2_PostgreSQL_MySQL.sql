--SQL Server DB2 PostgreSQL MySQL
ALTER TABLE Shohin DROP COLUMN shohin_mei_kana;