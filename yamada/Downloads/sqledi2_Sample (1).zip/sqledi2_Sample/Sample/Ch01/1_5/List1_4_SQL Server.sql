--SQL Server
ALTER TABLE Shohin ADD shohin_mei_kana VARCHAR(100);